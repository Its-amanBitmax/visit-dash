<?php $__env->startSection('title', 'Evaluation Details'); ?>
<?php $__env->startSection('header', 'Evaluation Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-card" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <div>
            <div style="font-size:18px;font-weight:700;">Evaluation #<?php echo e($evaluation->id); ?></div>
            <div style="color:#606776;">Agent <?php echo e($evaluation->agent_id); ?> - <?php echo e($evaluation->agent_name); ?></div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <a class="btn" href="<?php echo e(route('agent-chat-evaluations.pdf', $evaluation->id)); ?>">Download PDF</a>
            <a class="btn btn-secondary" href="<?php echo e(route('agent-chat-evaluations.edit', $evaluation->id)); ?>">Edit</a>
            <a class="btn" href="<?php echo e(route('agent-chat-evaluations.index')); ?>">Back</a>
        </div>
    </div>

    <?php if(session('status')): ?>
        <div class="page-card" style="border-color:#bfdbfe;background:#eff6ff;color:#1e3a8a;">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="page-card" style="display:grid;gap:18px;">
        <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;">
            <div class="card" style="box-shadow:none;border:1px solid #eef2f7;">
                <div style="font-size:13px;text-transform:uppercase;letter-spacing:0.8px;color:#606776;margin-bottom:10px;">Basic Details</div>
                <div style="display:grid;gap:6px;">
                    <div>Project: <strong><?php echo e($evaluation->project_name); ?></strong></div>
                    <div>Center: <strong><?php echo e($evaluation->center_name); ?></strong></div>
                    <div>Location: <strong><?php echo e($evaluation->location); ?></strong></div>
                    <div>Evaluator: <strong><?php echo e($evaluation->evaluator_name); ?></strong></div>
                </div>
            </div>
            <div class="card" style="box-shadow:none;border:1px solid #eef2f7;">
                <div style="font-size:13px;text-transform:uppercase;letter-spacing:0.8px;color:#606776;margin-bottom:10px;">Overall</div>
                <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                    <div style="font-size:28px;font-weight:700;color:#1d4ed8;"><?php echo e($evaluation->overall_score); ?></div>
                    <div style="color:#606776;"><?php echo e($evaluation->percentage); ?>% Score</div>
                </div>
            </div>
        </div>

        <div class="card" style="box-shadow:none;border:1px solid #eef2f7;">
            <div style="font-size:13px;text-transform:uppercase;letter-spacing:0.8px;color:#606776;margin-bottom:10px;">Scores Breakdown</div>
            <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;">
                <div>Communication Skills: <strong><?php echo e($evaluation->communication_skills); ?></strong></div>
                <div>Opening/Closing: <strong><?php echo e($evaluation->opening_closing); ?></strong></div>
                <div>Grammar: <strong><?php echo e($evaluation->grammar); ?></strong></div>
                <div>Chat Etiquettes: <strong><?php echo e($evaluation->chat_etiquettes); ?></strong></div>
                <div>Scenario Based Questions: <strong><?php echo e($evaluation->scenario_based_questions); ?></strong></div>
                <div>Response Time: <strong><?php echo e($evaluation->response_time); ?></strong></div>
                <div>CRM Knowledge: <strong><?php echo e($evaluation->crm_knowledge); ?></strong></div>
                <div>Customer Handling: <strong><?php echo e($evaluation->customer_handling); ?></strong></div>
                <div>Quality/Accuracy: <strong><?php echo e($evaluation->quality_accuracy); ?></strong></div>
            </div>
        </div>

        <div class="card" style="box-shadow:none;border:1px solid #eef2f7;">
            <div style="font-size:13px;text-transform:uppercase;letter-spacing:0.8px;color:#606776;margin-bottom:10px;">Remarks</div>
            <div style="white-space:pre-line;"><?php echo e($evaluation->evaluator_remarks); ?></div>
        </div>

        <div class="card" style="box-shadow:none;border:1px solid #eef2f7;">
            <div style="font-size:13px;text-transform:uppercase;letter-spacing:0.8px;color:#606776;margin-bottom:10px;">Evaluation Date</div>
            <div><?php echo e($evaluation->column001); ?></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\visit report\resources\views/agent-chat-evaluations/show.blade.php ENDPATH**/ ?>