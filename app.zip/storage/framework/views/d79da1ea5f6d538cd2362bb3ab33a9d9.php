<?php $__env->startSection('title', 'Create Center Visit Evaluation'); ?>
<?php $__env->startSection('header', 'Create Center Visit'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-card" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <div>
            <div style="font-size:18px;font-weight:700;">New Center Visit Evaluation</div>
            <div style="color:#606776;">Fill in the details below.</div>
        </div>
        <a class="btn btn-secondary" href="<?php echo e(route('center-visit-evaluations.index')); ?>">Back</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="page-card" style="border-color:#fecaca;background:#fef2f2;color:#991b1b;">
            <ul style="margin:0;padding-left:18px;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('center-visit-evaluations.store')); ?>" class="page-card form-grid">
        <?php echo csrf_field(); ?>

        <div class="form-section">
            <h3>Basic Details</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Center Name</label>
                    <input type="text" name="center_name" value="<?php echo e(old('center_name')); ?>" required>
                </div>
                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="location" value="<?php echo e(old('location')); ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Visit Date</label>
                    <input type="date" name="visit_date" value="<?php echo e(old('visit_date')); ?>" required>
                </div>
                <div class="form-group">
                    <label>Duration</label>
                    <input type="text" name="duration" value="<?php echo e(old('duration')); ?>" required>
                </div>
            </div>
        </div>

        <div class="form-section">
            <h3>Infrastructure</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Infrastructure by Client</label>
                    <select name="infrastructure_by_client" required>
                        <option value="">Select</option>
                        <option value="meet" <?php if(old('infrastructure_by_client') === 'meet'): echo 'selected'; endif; ?>>Meet</option>
                        <option value="not_meet" <?php if(old('infrastructure_by_client') === 'not_meet'): echo 'selected'; endif; ?>>Not Meet</option>
                        <option value="need_change" <?php if(old('infrastructure_by_client') === 'need_change'): echo 'selected'; endif; ?>>Need Change</option>
                        <option value="action_required" <?php if(old('infrastructure_by_client') === 'action_required'): echo 'selected'; endif; ?>>Action Required</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Remarks</label>
                    <textarea name="remarks1"><?php echo e(old('remarks1')); ?></textarea>
                </div>
            </div>
        </div>

        <div class="form-section">
            <h3>Other Requirements</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>System Required by Client</label>
                    <select name="system_required_by_client" required>
                        <option value="">Select</option>
                        <option value="meet" <?php if(old('system_required_by_client') === 'meet'): echo 'selected'; endif; ?>>Meet</option>
                        <option value="not_meet" <?php if(old('system_required_by_client') === 'not_meet'): echo 'selected'; endif; ?>>Not Meet</option>
                        <option value="need_change" <?php if(old('system_required_by_client') === 'need_change'): echo 'selected'; endif; ?>>Need Change</option>
                        <option value="action_required" <?php if(old('system_required_by_client') === 'action_required'): echo 'selected'; endif; ?>>Action Required</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Remarks</label>
                    <textarea name="remarks2"><?php echo e(old('remarks2')); ?></textarea>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Manpower Required by Client</label>
                    <select name="manpower_required_by_client" required>
                        <option value="">Select</option>
                        <option value="meet" <?php if(old('manpower_required_by_client') === 'meet'): echo 'selected'; endif; ?>>Meet</option>
                        <option value="not_meet" <?php if(old('manpower_required_by_client') === 'not_meet'): echo 'selected'; endif; ?>>Not Meet</option>
                        <option value="need_change" <?php if(old('manpower_required_by_client') === 'need_change'): echo 'selected'; endif; ?>>Need Change</option>
                        <option value="action_required" <?php if(old('manpower_required_by_client') === 'action_required'): echo 'selected'; endif; ?>>Action Required</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Remarks</label>
                    <textarea name="remarks3"><?php echo e(old('remarks3')); ?></textarea>
                </div>
            </div>
        </div>

        <div class="form-section">
            <h3>Evaluator</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Evaluator Name</label>
                    <input type="text" name="evaluator_name" value="<?php echo e(old('evaluator_name')); ?>" required>
                </div>
                <div class="form-group">
                    <label>Evaluator Remarks</label>
                    <textarea name="evaluator_remarks"><?php echo e(old('evaluator_remarks')); ?></textarea>
                </div>
            </div>
        </div>

        <div style="display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap;">
            <button type="submit" class="btn">Save</button>
            <a class="btn btn-secondary" href="<?php echo e(route('center-visit-evaluations.index')); ?>">Back</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\visit report\resources\views/center-visit-evaluations/create.blade.php ENDPATH**/ ?>