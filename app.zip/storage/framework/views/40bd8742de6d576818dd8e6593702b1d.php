<?php $__env->startSection('title', 'Edit Evaluation'); ?>
<?php $__env->startSection('header', 'Edit Evaluation'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-card" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <div>
            <div style="font-size:18px;font-weight:700;">Edit Evaluation #<?php echo e($evaluation->id); ?></div>
            <div style="color:#606776;">Update the details below.</div>
        </div>
        <a class="btn btn-secondary" href="<?php echo e(route('agent-chat-evaluations.show', $evaluation->id)); ?>">Cancel</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="page-card" style="border-color:#fecaca;background:#fef2f2;color:#991b1b;">
            <ul style="margin:0;padding-left:18px;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('agent-chat-evaluations.update', $evaluation->id)); ?>" class="page-card form-grid">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-section">
            <h3>Basic</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Project Name</label>
                    <input type="text" name="project_name" value="<?php echo e(old('project_name', $evaluation->project_name)); ?>">
                </div>
                <div class="form-group">
                    <label>Center Name</label>
                    <input type="text" name="center_name" value="<?php echo e(old('center_name', $evaluation->center_name)); ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="location" value="<?php echo e(old('location', $evaluation->location)); ?>">
                </div>
                <div class="form-group">
                    <label>Evaluator Name</label>
                    <input type="text" name="evaluator_name" value="<?php echo e(old('evaluator_name', $evaluation->evaluator_name)); ?>">
                </div>
            </div>
        </div>

        <div class="form-section">
            <h3>Agent</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Agent ID</label>
                    <input type="text" name="agent_id" value="<?php echo e(old('agent_id', $evaluation->agent_id)); ?>">
                </div>
                <div class="form-group">
                    <label>Agent Name</label>
                    <input type="text" name="agent_name" value="<?php echo e(old('agent_name', $evaluation->agent_name)); ?>">
                </div>
            </div>
        </div>

        <div class="form-section">
            <h3>Scores</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Communication Skills (0-10)</label>
                    <input type="number" name="communication_skills" min="0" max="10" value="<?php echo e(old('communication_skills', $evaluation->communication_skills)); ?>">
                </div>
                <div class="form-group">
                    <label>Opening/Closing (0-10)</label>
                    <input type="number" name="opening_closing" min="0" max="10" value="<?php echo e(old('opening_closing', $evaluation->opening_closing)); ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Grammar (0-10)</label>
                    <input type="number" name="grammar" min="0" max="10" value="<?php echo e(old('grammar', $evaluation->grammar)); ?>">
                </div>
                <div class="form-group">
                    <label>Chat Etiquettes (0-10)</label>
                    <input type="number" name="chat_etiquettes" min="0" max="10" value="<?php echo e(old('chat_etiquettes', $evaluation->chat_etiquettes)); ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Scenario Based (0-20)</label>
                    <input type="number" name="scenario_based_questions" min="0" max="20" value="<?php echo e(old('scenario_based_questions', $evaluation->scenario_based_questions)); ?>">
                </div>
                <div class="form-group">
                    <label>Response Time (0-10)</label>
                    <input type="number" name="response_time" min="0" max="10" value="<?php echo e(old('response_time', $evaluation->response_time)); ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>CRM Knowledge (0-10)</label>
                    <input type="number" name="crm_knowledge" min="0" max="10" value="<?php echo e(old('crm_knowledge', $evaluation->crm_knowledge)); ?>">
                </div>
                <div class="form-group">
                    <label>Customer Handling (0-10)</label>
                    <input type="number" name="customer_handling" min="0" max="10" value="<?php echo e(old('customer_handling', $evaluation->customer_handling)); ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Quality/Accuracy (0-10)</label>
                    <input type="number" name="quality_accuracy" min="0" max="10" value="<?php echo e(old('quality_accuracy', $evaluation->quality_accuracy)); ?>">
                </div>
            </div>
        </div>

        <div class="form-section">
            <h3>Remarks</h3>
            <div class="form-group">
                <label>Evaluator Remarks</label>
                <textarea name="evaluator_remarks"><?php echo e(old('evaluator_remarks', $evaluation->evaluator_remarks)); ?></textarea>
            </div>
        </div>

        <div class="form-section">
            <h3>Evaluation Date</h3>
            <div class="form-group">
                <label>Date of Evaluation</label>
                <input type="date" name="column001" value="<?php echo e(old('column001', $evaluation->column001)); ?>">
            </div>
        </div>

        <div style="display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap;">
            <button type="submit" class="btn">Update</button>
            <a class="btn btn-secondary" href="<?php echo e(route('agent-chat-evaluations.show', $evaluation->id)); ?>">Cancel</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\visit report\resources\views/agent-chat-evaluations/edit.blade.php ENDPATH**/ ?>