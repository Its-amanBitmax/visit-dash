<?php $__env->startSection('title', 'Agent Chat Evaluations'); ?>
<?php $__env->startSection('header', 'Agent Chat Evaluations'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-card" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <div>
            <div style="font-size:18px;font-weight:700;">All Evaluations</div>
            <div style="color:#606776;">Manage and review agent chat evaluations.</div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
            <form method="GET" action="<?php echo e(route('agent-chat-evaluations.index')); ?>" data-live-search
                  style="display:flex;gap:8px;align-items:center;">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search agent / project / evaluator"
                       style="padding:10px 12px;border-radius:12px;border:1px solid #e5e7eb;font-size:14px;">
            </form>
            <a class="btn btn-secondary" href="<?php echo e(route('agent-chat-evaluations.pdf.all')); ?>">Download All PDF</a>
            <a class="btn" href="<?php echo e(route('agent-chat-evaluations.create')); ?>">Create New</a>
        </div>
    </div>

    <?php if(session('status')): ?>
        <div class="page-card" style="border-color:#bfdbfe;background:#eff6ff;color:#1e3a8a;">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="page-card">
        <div class="table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Agent</th>
                        <th>Eval Date</th>
                        <th>Overall</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration + ($evaluations->currentPage() - 1) * $evaluations->perPage()); ?></td>
                            <td><?php echo e($evaluation->agent_id); ?> - <?php echo e($evaluation->agent_name); ?></td>
                            <td><?php echo e($evaluation->column001); ?></td>
                            <td><?php echo e($evaluation->overall_score); ?></td>
                            <td><?php echo e($evaluation->created_at); ?></td>
                            <td style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                                <a class="btn" href="<?php echo e(route('agent-chat-evaluations.pdf', $evaluation->id)); ?>">PDF</a>
                                <a class="btn btn-secondary" href="<?php echo e(route('agent-chat-evaluations.show', $evaluation->id)); ?>">View</a>
                                <a class="btn btn-secondary" href="<?php echo e(route('agent-chat-evaluations.edit', $evaluation->id)); ?>">Edit</a>
                                <form method="POST" action="<?php echo e(route('agent-chat-evaluations.destroy', $evaluation->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger" type="submit" onclick="return confirm('Delete this evaluation?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" style="text-align:center;color:#606776;">No evaluations found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div style="margin-top:14px;">
            <?php echo e($evaluations->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    (function () {
        const form = document.querySelector('form[data-live-search]');
        if (!form) return;
        const input = form.querySelector('input[name="search"]');
        let timer;
        input.addEventListener('input', () => {
            clearTimeout(timer);
            timer = setTimeout(() => form.submit(), 300);
        });
    })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\visit report\resources\views/agent-chat-evaluations/index.blade.php ENDPATH**/ ?>