<?php $__env->startSection('title', 'Manage Admins'); ?>
<?php $__env->startSection('header', 'Manage Admins'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-card" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <div>
            <div style="font-size:18px;font-weight:700;">All Admins</div>
            <div style="color:#606776;">Only you can access this module.</div>
        </div>
        <a class="btn" href="<?php echo e(route('admin.management.create')); ?>">Create Admin</a>
    </div>

    <?php if(session('status')): ?>
        <div class="page-card" style="border-color:#bfdbfe;background:#eff6ff;color:#1e3a8a;">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="page-card">
        <div class="table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration + ($admins->currentPage() - 1) * $admins->perPage()); ?></td>
                            <td><?php echo e($admin->name); ?></td>
                            <td><?php echo e($admin->username); ?></td>
                            <td><?php echo e($admin->email); ?></td>
                            <td><?php echo e($admin->created_at); ?></td>
                            <td style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                                <a class="btn btn-secondary" href="<?php echo e(route('admin.management.edit', $admin->id)); ?>">Edit</a>
                                <?php if((int) $admin->id !== 1): ?>
                                    <form method="POST" action="<?php echo e(route('admin.management.destroy', $admin->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger" type="submit" onclick="return confirm('Delete this admin?')">Delete</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" style="text-align:center;color:#606776;">No admins found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div style="margin-top:14px;">
            <?php echo e($admins->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\visit report\resources\views/admin-management/index.blade.php ENDPATH**/ ?>