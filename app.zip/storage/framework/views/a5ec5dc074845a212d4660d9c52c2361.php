<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<?php $__env->startSection('header', 'Dashboard Overview'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h2 style="margin-top:0;">Welcome back, <?php echo e(auth('admin')->user()->name ?? 'Admin'); ?></h2>
        <p style="margin-bottom:0;color:#5a6473;">
            This is your admin dashboard. Use the sidebar to navigate between visits, reports, and settings.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\visit report\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>